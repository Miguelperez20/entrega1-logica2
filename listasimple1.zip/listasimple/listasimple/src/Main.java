import java.util.Scanner;

// Clase Nodo
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// Clase Lista Enlazada
class LinkedList {
    private Node head;

    
    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newNode;
    }

    
    public void delete(int value) {
        if (head == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        if (head.data == value) {
            head = head.next;
            return;
        }
        Node temp = head;
        while (temp.next != null && temp.next.data != value) {
            temp = temp.next;
        }
        if (temp.next != null) {
            temp.next = temp.next.next;
        } else {
            System.out.println("Valor no encontrado en la lista.");
        }
    }

    
    public void display() {
        if (head == null) {
            System.out.println("La lista está vacía.");
            return;
        }
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("null");
    }
}


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList list = new LinkedList();
        int option, value;

        do {
            System.out.println("\n📌 Menú de Lista Enlazada");
            System.out.println("1. Agregar número");
            System.out.println("2. Eliminar número");
            System.out.println("3. Mostrar lista");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Ingrese el número a agregar: ");
                    value = scanner.nextInt();
                    list.add(value);
                    break;
                case 2:
                    System.out.print("Ingrese el número a eliminar: ");
                    value = scanner.nextInt();
                    list.delete(value);
                    break;
                case 3:
                    System.out.println("Lista actual:");
                    list.display();
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, intenta de nuevo.");
            }
        } while (option != 4);

        scanner.close();
    }
}