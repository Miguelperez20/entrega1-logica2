import javax.swing.JOptionPane;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    private Node head;
    private Node tail;

    public CircularLinkedList() {
        this.head = null;
        this.tail = null;
    }

    
    public void append(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
            newNode.next = head; 
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head; 
        }
    }

    
    public void display() {
        if (head == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía");
            return;
        }
        Node current = head;
        StringBuilder listContent = new StringBuilder();
        do {
            listContent.append(current.data).append(" -> ");
            current = current.next;
        } while (current != head);
        listContent.append("(head)");
        JOptionPane.showMessageDialog(null, listContent.toString());
    }

    
    public void delete(int key) {
        if (head == null) return;

        Node current = head;
        Node prev = null;

        
        if (current != null && current.data == key) {
            if (current == tail) { 
                head = null;
                tail = null;
            } else {
                tail.next = head.next;
                head = head.next;
            }
            return;
        }

        
        do {
            prev = current;
            current = current.next;
        } while (current != head && current.data != key);

        
        if (current == head) return;

        
        prev.next = current.next;
        if (current == tail) {
            tail = prev;
        }
    }

    
    public boolean search(int key) {
        if (head == null) return false;

        Node current = head;
        do {
            if (current.data == key) {
                return true;
            }
            current = current.next;
        } while (current != head);
        return false;
    }
}

public class CircularLinkedListGUI {
    public static void main(String[] args) {
        CircularLinkedList cll = new CircularLinkedList();

        while (true) {
            String[] options = {"Agregar", "Eliminar", "Buscar", "Mostrar", "Salir"};
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una operación",
                    "Lista Circular Enlazada",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == 0) {
                String input = JOptionPane.showInputDialog("Ingrese un número para agregar:");
                int data = Integer.parseInt(input);
                cll.append(data);
            } else if (choice == 1) {
                String input = JOptionPane.showInputDialog("Ingrese un número para eliminar:");
                int data = Integer.parseInt(input);
                cll.delete(data);
            } else if (choice == 2) {
                String input = JOptionPane.showInputDialog("Ingrese un número para buscar:");
                int data = Integer.parseInt(input);
                boolean found = cll.search(data);
                JOptionPane.showMessageDialog(null, found ? "Número encontrado" : "Número no encontrado");
            } else if (choice == 3) {
                cll.display();
            } else if (choice == 4) {
                break;
            }
        }
    }
}